use std::io::{Stdout, stdout};
use std::time::Duration;

use anyhow::Result;
use crossterm::cursor::{Hide, Show};
use crossterm::event::{self, Event, KeyCode, KeyEventKind, KeyModifiers};
use crossterm::execute;
use crossterm::terminal::{
    EnterAlternateScreen, LeaveAlternateScreen, disable_raw_mode, enable_raw_mode,
};
use ratatui::Frame;
use ratatui::Terminal as RatatuiTerminal;
use ratatui::backend::CrosstermBackend;
use ratatui::layout::{Alignment, Constraint, Direction, Layout, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, Clear, Paragraph, Wrap};

use crate::catalog::Catalog;
use crate::patterns::PACKET_LEN;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoopStatus {
    Idle,
    Looping,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CommandInfo {
    pub key: char,
    pub name: String,
    pub desc: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RoutineCategory {
    pub title: String,
    pub commands: Vec<CommandInfo>,
}

/// Preferred dashboard card order. New categories from show files are appended.
pub const DEFAULT_CATEGORY_TITLES: [&str; 4] = [
    "Flashes & Solids",
    "Twinkles & Sparkles",
    "Animations & Marquees",
    "Holiday & Specials",
];

/// Build command cards from whatever shows the catalog loaded.
#[must_use]
pub fn get_categories(catalog: &Catalog) -> Vec<RoutineCategory> {
    use std::collections::BTreeMap;

    let mut by_cat: BTreeMap<String, Vec<CommandInfo>> = BTreeMap::new();
    for show in catalog.shows() {
        by_cat
            .entry(show.category.clone())
            .or_default()
            .push(CommandInfo {
                key: show.key,
                name: show.name.clone(),
                desc: show.desc.clone(),
            });
    }
    for commands in by_cat.values_mut() {
        commands.sort_by_key(|cmd| cmd.key);
    }

    let mut titles: Vec<String> = DEFAULT_CATEGORY_TITLES
        .iter()
        .map(|title| (*title).to_owned())
        .collect();
    for title in by_cat.keys() {
        if !titles.iter().any(|existing| existing == title) {
            titles.push(title.clone());
        }
    }

    titles
        .into_iter()
        .filter_map(|title| {
            let commands = by_cat.remove(&title)?;
            if commands.is_empty() {
                None
            } else {
                Some(RoutineCategory { title, commands })
            }
        })
        .collect()
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UiState {
    pub current_routine: String,
    pub loop_status: LoopStatus,
    pub last_key: Option<char>,
    pub packet_count: u64,
    pub last_packet: [u8; PACKET_LEN],
    pub categories: Vec<RoutineCategory>,
    pub status_message: Option<String>,
    pub is_error: bool,
    pub device_connected: bool,
    pub removal_warning: bool,
    pub port_label: String,
}

impl Default for UiState {
    fn default() -> Self {
        Self {
            current_routine: "IDLE".to_string(),
            loop_status: LoopStatus::Idle,
            last_key: None,
            packet_count: 0,
            last_packet: [0; PACKET_LEN],
            categories: Vec::new(),
            status_message: Some("System Ready - Listening for commands".to_string()),
            is_error: false,
            device_connected: true,
            removal_warning: false,
            port_label: "FTDI 57600 8N1".to_string(),
        }
    }
}

pub struct Terminal {
    inner: RatatuiTerminal<CrosstermBackend<Stdout>>,
}

impl Terminal {
    /// Initializes terminal raw mode and alternate screen with Ratatui backend (RAII).
    ///
    /// # Errors
    ///
    /// Returns an error if enabling raw mode, entering the alternate screen, hiding the cursor, or initializing the Ratatui backend fails.
    pub fn new() -> Result<Self> {
        enable_raw_mode()?;
        let mut stdout = stdout();
        execute!(stdout, EnterAlternateScreen, Hide)?;
        let backend = CrosstermBackend::new(stdout);
        let inner = RatatuiTerminal::new(backend)?;
        Ok(Self { inner })
    }

    /// Draws the complete UI frame using the provided `UiState` snapshot.
    ///
    /// # Errors
    ///
    /// Returns an error if drawing the frame onto the terminal backend fails.
    pub fn draw(&mut self, state: &UiState) -> Result<()> {
        self.inner.draw(|frame| {
            render_ui(frame, state);
        })?;
        Ok(())
    }

    /// Non-blocking keyboard poll. Maps Ctrl-C to `Some('.')`.
    #[must_use]
    pub fn poll_key() -> Option<char> {
        if let Ok(true) = event::poll(Duration::ZERO)
            && let Ok(Event::Key(key_event)) = event::read()
            && key_event.kind == KeyEventKind::Press
        {
            if key_event.modifiers.contains(KeyModifiers::CONTROL)
                && key_event.code == KeyCode::Char('c')
            {
                return Some('.');
            }
            if let KeyCode::Char(c) = key_event.code {
                return Some(c);
            }
        }
        None
    }
}

pub fn render_ui(frame: &mut Frame, state: &UiState) {
    let size = frame.area();

    // Main vertical layout
    let main_chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(3), // Header
            Constraint::Min(12),   // Command cards grid
            Constraint::Length(7), // Status & Visualizer panel
            Constraint::Length(1), // Footer keybar
        ])
        .split(size);

    render_header(frame, main_chunks[0], state);
    render_command_grid(frame, main_chunks[1], state);
    render_status_and_preview(frame, main_chunks[2], state);
    render_footer(frame, main_chunks[3]);
    if state.removal_warning {
        render_removal_warning(frame, size);
    }
}

fn render_removal_warning(frame: &mut Frame, area: Rect) {
    let width = area.width.min(68);
    let height = area.height.min(9);
    if width == 0 || height == 0 {
        return;
    }

    let popup = Rect::new(
        area.x + area.width.saturating_sub(width) / 2,
        area.y + area.height.saturating_sub(height) / 2,
        width,
        height,
    );
    let warning_style = Style::default()
        .fg(Color::White)
        .bg(Color::DarkGray)
        .add_modifier(Modifier::BOLD);
    let content = vec![
        Line::from(Span::styled(
            "The USB transmitter was removed.",
            warning_style,
        )),
        Line::from("Broadcasting has stopped."),
        Line::from("Reconnect it and restart the application to resume."),
        Line::from(""),
        Line::from(Span::styled(
            "Press Enter or Esc to dismiss  |  . to quit",
            warning_style,
        )),
    ];
    let dialog = Paragraph::new(content)
        .block(
            Block::default()
                .title(" TRANSMITTER REMOVED ")
                .borders(Borders::ALL)
                .border_type(BorderType::Double)
                .border_style(Style::default().fg(Color::Red).add_modifier(Modifier::BOLD))
                .style(Style::default().bg(Color::DarkGray)),
        )
        .alignment(Alignment::Center)
        .wrap(Wrap { trim: true });
    frame.render_widget(Clear, popup);
    frame.render_widget(dialog, popup);
}

fn render_header(frame: &mut Frame, area: Rect, state: &UiState) {
    let header_chunks = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(50), Constraint::Percentage(50)])
        .split(area);

    let title_line = Line::from(vec![
        Span::styled("⚡ ", Style::default().fg(Color::Yellow)),
        Span::styled(
            "Ben's Halftime Light Show Toolkit",
            Style::default()
                .fg(Color::Cyan)
                .add_modifier(Modifier::BOLD),
        ),
    ]);

    let title_para = Paragraph::new(title_line)
        .block(
            Block::default()
                .borders(Borders::ALL)
                .border_type(BorderType::Rounded)
                .border_style(Style::default().fg(Color::Cyan)),
        )
        .alignment(Alignment::Left);
    frame.render_widget(title_para, header_chunks[0]);

    let (conn_text, conn_color) = if state.device_connected {
        ("● ONLINE", Color::Green)
    } else {
        ("○ OFFLINE", Color::Red)
    };

    let status_line = Line::from(vec![
        Span::styled("PORT: ", Style::default().fg(Color::DarkGray)),
        Span::styled(
            format!("{} ", state.port_label),
            Style::default().fg(Color::White),
        ),
        Span::styled("| ", Style::default().fg(Color::DarkGray)),
        Span::styled("STATUS: ", Style::default().fg(Color::DarkGray)),
        Span::styled(
            conn_text,
            Style::default().fg(conn_color).add_modifier(Modifier::BOLD),
        ),
    ]);

    let status_para = Paragraph::new(status_line)
        .block(
            Block::default()
                .borders(Borders::ALL)
                .border_type(BorderType::Rounded)
                .border_style(Style::default().fg(Color::Cyan)),
        )
        .alignment(Alignment::Right);
    frame.render_widget(status_para, header_chunks[1]);
}

fn render_command_grid(frame: &mut Frame, area: Rect, state: &UiState) {
    let categories = &state.categories;
    let grid_rows = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Percentage(50), Constraint::Percentage(50)])
        .split(area);

    let top_cols = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(50), Constraint::Percentage(50)])
        .split(grid_rows[0]);

    let bottom_cols = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(50), Constraint::Percentage(50)])
        .split(grid_rows[1]);

    let slots = [top_cols[0], top_cols[1], bottom_cols[0], bottom_cols[1]];
    let border_colors = [Color::Magenta, Color::Blue, Color::Green, Color::Yellow];

    for (i, cat) in categories.iter().enumerate() {
        if i >= slots.len() {
            break;
        }

        let mut lines = Vec::new();
        for cmd in &cat.commands {
            lines.push(Line::from(vec![
                Span::styled(
                    format!("[{}] ", cmd.key),
                    Style::default()
                        .fg(Color::Yellow)
                        .add_modifier(Modifier::BOLD),
                ),
                Span::styled(cmd.name.as_str(), Style::default().fg(Color::White)),
                Span::styled(
                    format!(" - {}", cmd.desc),
                    Style::default().fg(Color::DarkGray),
                ),
            ]));
        }

        let card = Paragraph::new(lines)
            .block(
                Block::default()
                    .title(format!(" {} ", cat.title))
                    .title_style(
                        Style::default()
                            .fg(border_colors[i])
                            .add_modifier(Modifier::BOLD),
                    )
                    .borders(Borders::ALL)
                    .border_type(BorderType::Rounded)
                    .border_style(Style::default().fg(border_colors[i])),
            )
            .wrap(Wrap { trim: true });

        frame.render_widget(card, slots[i]);
    }
}

fn render_status_and_preview(frame: &mut Frame, area: Rect, state: &UiState) {
    let block = Block::default()
        .title(" System Status & Channel Visualizer ")
        .title_style(
            Style::default()
                .fg(Color::White)
                .add_modifier(Modifier::BOLD),
        )
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::default().fg(Color::DarkGray));

    let inner_area = block.inner(area);
    frame.render_widget(block, area);

    let (loop_text, loop_style) = match state.loop_status {
        LoopStatus::Idle => ("[IDLE]", Style::default().fg(Color::DarkGray)),
        LoopStatus::Looping => (
            "[LOOPING]",
            Style::default()
                .fg(Color::Yellow)
                .add_modifier(Modifier::BOLD),
        ),
    };

    let key_display = match state.last_key {
        Some(k) => format!("'{k}'"),
        None => "None".to_string(),
    };

    let line1 = Line::from(vec![
        Span::styled("ROUTINE: ", Style::default().fg(Color::DarkGray)),
        Span::styled(
            &state.current_routine,
            Style::default()
                .fg(Color::Cyan)
                .add_modifier(Modifier::BOLD),
        ),
        Span::raw("  "),
        Span::styled(loop_text, loop_style),
        Span::raw("   "),
        Span::styled("LAST KEY: ", Style::default().fg(Color::DarkGray)),
        Span::styled(key_display, Style::default().fg(Color::White)),
        Span::raw("   "),
        Span::styled("PACKETS: ", Style::default().fg(Color::DarkGray)),
        Span::styled(
            format!("{}", state.packet_count),
            Style::default()
                .fg(Color::Magenta)
                .add_modifier(Modifier::BOLD),
        ),
    ]);

    // Visualizer line for 32 RGB channels
    let mut vis_spans = vec![Span::styled(
        "CHANNELS (1-32): ",
        Style::default().fg(Color::DarkGray),
    )];
    for ch in 0..32 {
        let r = state.last_packet[ch * 3];
        let g = state.last_packet[ch * 3 + 1];
        let b = state.last_packet[ch * 3 + 2];
        if r == 0 && g == 0 && b == 0 {
            vis_spans.push(Span::styled("·", Style::default().fg(Color::DarkGray)));
        } else {
            vis_spans.push(Span::styled("█", Style::default().fg(Color::Rgb(r, g, b))));
        }
        if ch < 31 {
            vis_spans.push(Span::raw(" "));
        }
    }
    let line2 = Line::from(vis_spans);

    // Message line
    let line3 = if state.is_error {
        Line::from(vec![
            Span::styled(
                "ERROR: ",
                Style::default().fg(Color::Red).add_modifier(Modifier::BOLD),
            ),
            Span::styled(
                state.status_message.as_deref().unwrap_or("Hardware Error"),
                Style::default().fg(Color::Red),
            ),
        ])
    } else {
        Line::from(vec![
            Span::styled("LOG: ", Style::default().fg(Color::DarkGray)),
            Span::styled(
                state.status_message.as_deref().unwrap_or("System Idle"),
                Style::default().fg(Color::Green),
            ),
        ])
    };

    let content_lines = vec![line1, line2, line3];
    let para = Paragraph::new(content_lines);
    frame.render_widget(para, inner_area);
}

fn render_footer(frame: &mut Frame, area: Rect) {
    let keybar = Line::from(vec![
        Span::styled(
            " [,] ",
            Style::default()
                .fg(Color::Yellow)
                .add_modifier(Modifier::BOLD),
        ),
        Span::styled("Stop Loop", Style::default().fg(Color::White)),
        Span::raw("   "),
        Span::styled(
            " [.] / [Ctrl-C] ",
            Style::default().fg(Color::Red).add_modifier(Modifier::BOLD),
        ),
        Span::styled("Quit", Style::default().fg(Color::White)),
        Span::raw("   "),
        Span::styled(
            " [<] ",
            Style::default()
                .fg(Color::Cyan)
                .add_modifier(Modifier::BOLD),
        ),
        Span::styled("Dim", Style::default().fg(Color::DarkGray)),
        Span::raw("   "),
        Span::styled(
            " [>] ",
            Style::default()
                .fg(Color::Cyan)
                .add_modifier(Modifier::BOLD),
        ),
        Span::styled("Brighten", Style::default().fg(Color::DarkGray)),
    ]);

    let footer_para = Paragraph::new(keybar).alignment(Alignment::Center);
    frame.render_widget(footer_para, area);
}

impl Drop for Terminal {
    fn drop(&mut self) {
        let _ = execute!(self.inner.backend_mut(), Show, LeaveAlternateScreen);
        let _ = disable_raw_mode();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    use ratatui::Terminal as RatatuiTerminal;
    use ratatui::backend::TestBackend;

    use crate::catalog::{Op, Show, Wait};
    use crate::patterns::{DARK, WHITE};

    fn sample_catalog() -> Catalog {
        let show = |key, name: &str, category: &str| Show {
            key,
            name: name.to_owned(),
            category: category.to_owned(),
            desc: "test cue".to_owned(),
            looping: key == 'c',
            program: vec![Op::Hold {
                frame: "white".to_owned(),
                wait: Wait::Ms(1),
            }],
        };
        let frames = HashMap::from([("white".to_owned(), WHITE), ("dark".to_owned(), DARK)]);
        Catalog::new(
            frames,
            vec![
                show('w', "White Flash", "Flashes & Solids"),
                show('c', "Christmas Sparkle", "Twinkles & Sparkles"),
            ],
        )
        .expect("catalog")
    }

    #[test]
    fn test_default_ui_state() {
        let state = UiState::default();
        assert_eq!(state.current_routine, "IDLE");
        assert_eq!(state.loop_status, LoopStatus::Idle);
        assert_eq!(state.packet_count, 0);
        assert!(!state.is_error);
        assert!(state.device_connected);
        assert!(!state.removal_warning);
        assert_eq!(state.categories, &[]);
    }

    #[test]
    fn test_categories_from_catalog() {
        let categories = get_categories(&sample_catalog());
        assert_eq!(categories.len(), 2);
        assert_eq!(categories[0].title, "Flashes & Solids");
        assert_eq!(categories[1].title, "Twinkles & Sparkles");
        assert_eq!(categories[0].commands[0].name, "White Flash");
        assert_eq!(categories[1].commands[0].key, 'c');
    }

    #[test]
    fn test_render_default_dashboard() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = RatatuiTerminal::new(backend).unwrap();
        let state = UiState::default();

        terminal
            .draw(|f| {
                render_ui(f, &state);
            })
            .unwrap();

        let buffer = terminal.backend().buffer();
        let content = format!("{buffer:?}");
        assert!(content.contains("Ben's Halftime Light Show Toolkit"));
        assert!(content.contains("ONLINE"));
        assert!(content.contains("[IDLE]"));
        assert!(content.contains("FTDI 57600 8N1"));
    }

    #[test]
    fn test_render_looping_and_error_state() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = RatatuiTerminal::new(backend).unwrap();
        let state = UiState {
            categories: get_categories(&sample_catalog()),
            current_routine: "Christmas Sparkle".to_string(),
            loop_status: LoopStatus::Looping,
            last_key: Some('c'),
            packet_count: 42,
            is_error: true,
            port_label: "ESP32-H2 USB".to_string(),
            status_message: Some("USB timeout writing endpoint".to_string()),
            last_packet: {
                let mut p = [0u8; 96];
                p[0] = 255;
                p
            },
            ..UiState::default()
        };

        terminal
            .draw(|f| {
                render_ui(f, &state);
            })
            .unwrap();

        let buffer = terminal.backend().buffer();
        let content = format!("{buffer:?}");
        assert!(content.contains("Christmas Sparkle"));
        assert!(content.contains("[LOOPING]"));
        assert!(content.contains("ERROR"));
        assert!(content.contains("USB timeout writing endpoint"));
        assert!(content.contains("ESP32-H2 USB"));
    }

    #[test]
    fn test_render_removed_device_warning_over_offline_dashboard() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = RatatuiTerminal::new(backend).unwrap();
        let state = UiState {
            device_connected: false,
            removal_warning: true,
            ..UiState::default()
        };

        terminal.draw(|frame| render_ui(frame, &state)).unwrap();

        let content = format!("{:?}", terminal.backend().buffer());
        assert!(content.contains("OFFLINE"));
        assert!(content.contains("TRANSMITTER REMOVED"));
        assert!(content.contains("The USB transmitter was removed."));
        assert!(content.contains("Press Enter or Esc to dismiss"));
    }

    #[test]
    fn test_render_constrained_dimensions() {
        let backend = TestBackend::new(40, 15);
        let mut terminal = RatatuiTerminal::new(backend).unwrap();
        let state = UiState::default();

        // Ensure small dimensions render without panicking
        let result = terminal.draw(|f| {
            render_ui(f, &state);
        });
        assert!(result.is_ok());
    }

    #[test]
    fn test_render_warning_on_tiny_terminal() {
        let backend = TestBackend::new(12, 4);
        let mut terminal = RatatuiTerminal::new(backend).unwrap();
        let state = UiState {
            device_connected: false,
            removal_warning: true,
            ..UiState::default()
        };

        assert!(terminal.draw(|frame| render_ui(frame, &state)).is_ok());
    }
}
